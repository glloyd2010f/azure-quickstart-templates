using System.Net;
using Newtonsoft.Json.Linq;
using System.IO;    
using System.Text; 
using Microsoft.Azure;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
public static void Run(string myEventHubMessage, TraceWriter log)
{
	
    
    CloudStorageAccount storageAccount = CloudStorageAccount.Parse(
    System.Configuration.ConfigurationManager.AppSettings["elasticclusterstorage_STORAGE"].ToString());

    //blob client now
    CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();            

	//the container for this is companystyles
    CloudBlobContainer container = blobClient.GetContainerReference("publish");

    //Create a new container, if it does not exist
    container.CreateIfNotExists();
    // Set the permissions so the blobs are public. 
    BlobContainerPermissions permissions = new BlobContainerPermissions
    {
        PublicAccess = BlobContainerPublicAccessType.Blob
    };
	container.SetPermissions(permissions);
	// Prepare web request...
    //UploadFileToStorage(myEventHubMessage);
    JArray arr = JArray.Parse(myEventHubMessage);
    log.Info($"{arr.GetType()}");
    string url ;
	string kibanaFunctionHost=System.Environment.GetEnvironmentVariable("kibanaFunctionHost", EnvironmentVariableTarget.Process);
	string kibanaFunctionPath=System.Environment.GetEnvironmentVariable("kibanaFunctionPath", EnvironmentVariableTarget.Process);
	kibanaFunctionHost = kibanaFunctionHost + ".azurewebsites.net";
    foreach (JObject item in arr)
    {
        //var data=JObject.Parse(item)["data"].ToString();
        //string[] data=item["data"]["url"].ToString().split({'/'});
        // log.Info($"OBJECT:{data.GetType()}");

        if(item.GetValue("data")!=null){
				JToken urldata=item.GetValue("data");
				url = (string)urldata.SelectToken("url");
				string[] tokens = url.Split('/');
				log.Info($"TOKENSDATA:{tokens[3]}");
				if(tokens.Length>=7){
					 if(tokens[3]=="raw" && tokens[4]=="datasets"){
						 log.Info($"PRESENT in RAW{tokens[5]}");
						byte[]  data = Encoding.UTF8.GetBytes(myEventHubMessage);
						string requestURL="https://"+kibanaFunctionHost+kibanaFunctionPath;
						HttpWebRequest myRequest =
						(HttpWebRequest)WebRequest.Create(requestURL);
						myRequest.Method = "POST";
						myRequest.ContentType="application/x-www-form-urlencoded";
						myRequest.ContentLength = data.Length;
						Stream newStream=myRequest.GetRequestStream();
						// Send the data.
						newStream.Write(data,0,data.Length);
						newStream.Close();
						log.Info($"{url}");
					 }
					if(tokens[3]=="transformed" && tokens[4]=="datasets"){
						 log.Info($"PRESENT in transformed{tokens[5]}");
						byte[]  data = Encoding.UTF8.GetBytes(myEventHubMessage);
						string requestURL="https://"+kibanaFunctionHost+kibanaFunctionPath;
						HttpWebRequest myRequest =
						(HttpWebRequest)WebRequest.Create(requestURL);
						myRequest.Method = "POST";
						myRequest.ContentType="application/x-www-form-urlencoded";
						myRequest.ContentLength = data.Length;
						Stream newStream=myRequest.GetRequestStream();
						// Send the data.
						newStream.Write(data,0,data.Length);
						newStream.Close();
						log.Info($"{url}");

					}
				}

							else if(tokens[3]=="publish" && tokens[5].Contains(".csv")){
					//log.Info($"C# Event Hub trigger function processed a message: {myEventHubMessage}");
						 //log.Info($"PRESENT in publish{tokens[4]}");
						byte[]  data = Encoding.UTF8.GetBytes(myEventHubMessage);
						string requestURL="https://"+kibanaFunctionHost+kibanaFunctionPath;
						HttpWebRequest myRequest =
						(HttpWebRequest)WebRequest.Create(requestURL);
						myRequest.Method = "POST";
						myRequest.ContentType="application/x-www-form-urlencoded";
						myRequest.ContentLength = data.Length;
						Stream newStream=myRequest.GetRequestStream();
						// Send the data.
						newStream.Write(data,0,data.Length);
						log.Info($"PRESENT in publish{myEventHubMessage}");
						newStream.Close();
						log.Info($"{url}");
				}
				else if(tokens.Length==5){
					 if(tokens[3]=="raw" && tokens[4]=="customer_updated_refrence.json" ){
						byte[]  data = Encoding.UTF8.GetBytes("{}");
						string requestURL="https://"+kibanaFunctionHost+kibanaFunctionPath;
						HttpWebRequest myRequest =
						(HttpWebRequest)WebRequest.Create(requestURL);
						myRequest.Method = "POST";
						myRequest.ContentType="application/x-www-form-urlencoded";
						myRequest.ContentLength = data.Length;
						Stream newStream=myRequest.GetRequestStream();
						// Send the data.
						newStream.Write(data,0,data.Length);
						newStream.Close();
					 }
				}
				else{//nothing

				}
			

        }


    }

}
