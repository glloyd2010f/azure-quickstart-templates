import os
import json, time
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname( __file__ ), 'env/Lib/site-packages')))

import requests
import uuid
from azure.mgmt.datalake.analytics.job.models import JobInformation, JobState, USqlJobProperties
from azure.common.credentials import ServicePrincipalCredentials
from azure.mgmt.datalake.analytics.job import DataLakeAnalyticsJobManagementClient

from utilities import df_run_id, df_status, adla_run_job_status,run_stream_job

response = open(os.environ['res'], 'w')
env = os.environ
function_app_name = env['function_app_name']
vm_ip = env['vm_ip']
discover_raw_dataset_run_id = 0
transformed_dataset_run_id = 0
function_app_url = '"https://' + function_app_name + '.azurewebsites.net/api/quickstart_wizard"'
get_token_app_url = '"https://' + function_app_name + '.azurewebsites.net/api/get_token_using_username_and_pwd"'


# Get HTTP METHOD
http_method = env['REQ_METHOD'] if 'REQ_METHOD' in env else "GET"
#print http_method

def second_df_starter():
    sub_id = env['subscription_id']
    rg_name = env['resource_group']
    df_name = env['datafactory_name']
    app_id = env['web_app_id']
    app_secret = env['web_app_secret']
    tenant = env['tenant']

    df_url = "https://management.azure.com/subscriptions/" + sub_id + "/resourceGroups/" + rg_name + "/providers/Microsoft.DataFactory/factories/" + df_name + "/pipelines/pipelineForDatatransformation2/createRun?api-version=2017-09-01-preview"
    run_id_json = df_run_id(df_url,app_id,app_secret,tenant)
    jsonresponse = run_id_json.json()
    run_id = jsonresponse['runId']
    # response.write(run_id)
    return run_id



if http_method == 'GET':
    with open('index.html', 'r') as f:
        html_in_string_format = f.read()
        returnData = {
            # HTTP Status Code:
            "status": 200,

            # Response Body:
            # "body":"process done",
            "body": html_in_string_format.replace('next_function_route', function_app_url),

            # Send any number of HTTP headers
            "headers": {
            "Content-Type": "text/html",
            "X-Awesome-Header": "YesItIs"
        }
        }
        response.write(json.dumps(returnData))

if http_method == 'POST':
    b = open(os.environ['req']).read() if os.environ['req'] else "'a':'b'"
    l = b.split('=')
    print(len(l))

    if len(l) == 2 :
        a = '{"' + l[0] + '":"' + l[1] + '"}'
    if len(l) > 2 :
        c = str(l[1]).split('&')
        node=l[2].split('&')
        print("C:",c)
        print("l:",node[0])
        print(len(c))
        a = '{"' + l[0] + '":"' + c[0]  +'","'+ c[1] + '":"' + node[0]+'"}'
    print(a)
    postreqdata = json.loads(a)

    if postreqdata['name'] == 'discover_raw_datasets':
        # headers = {'content-type': 'application/json'}
        # data={}
        # data=json.dumps(data)
        # requests.post('https://demotriggerappesfunction1234.azurewebsites.net/api/AddKibanaDashboard',data = data,headers = headers)

        sub_id = env['subscription_id']
        rg_name = env['resource_group']
        stg_name = env['storage_name']
        raw_url = "https://portal.azure.com/" + "#blade/Microsoft_Azure_Storage/ContainerMenuBlade/overview/storageAccountId/" + "%2Fsubscriptions%2F" +sub_id+ "%2FresourceGroups%2F"+rg_name+"%2Fproviders%2F"+"Microsoft.Storage%2F"+"storageAccounts%2F"+stg_name+"/path/raw"

        

        with open('discover_raw_datasets.html', 'r') as f:
            html_in_string_format = f.read()
            res_1 = html_in_string_format.replace('next_function_route', function_app_url)
            res_3 = res_1.replace('storagelinkholder',raw_url)
            returnData = {
                # HTTP Status Code:
                "status": 200,

                # Response Body:
                "body": res_3,

                # Send any number of HTTP headers
                "headers": {
                    "Content-Type": "text/html",
                    "X-Awesome-Header": "YesItIs"
                }
            }
            response.write(json.dumps(returnData))


    elif postreqdata['name'] == 'transform_dataset':
        sub_id = env['subscription_id']
        rg_name = env['resource_group']
        df_name = env['datafactory_name']
        app_id = env['web_app_id']
        app_secret = env['web_app_secret']
        tenant = env['tenant']
        df_url = "https://management.azure.com/subscriptions/" + sub_id + "/resourceGroups/" + rg_name + "/providers/Microsoft.DataFactory/factories/" + df_name + "/pipelines/pipelineForDataTransformation/createRun?api-version=2017-09-01-preview"
        run_id_json = df_run_id(df_url,app_id,app_secret,tenant)
        jsonresponse = run_id_json.json()
        run_id = jsonresponse['runId']
        response.write(run_id)

    elif postreqdata['name'] == 'adla':
        sub_id = env['subscription_id']
        rg_name = env['resource_group']
        tenant = env['tenant']
        adla_account_name = env['adla_account_name']

        stg_name = env['storage_name']

        publish_url = "https://portal.azure.com/" + "#blade/Microsoft_Azure_Storage/ContainerMenuBlade/overview/storageAccountId/" + "%2Fsubscriptions%2F" +sub_id+ "%2FresourceGroups%2F"+rg_name+"%2Fproviders%2F"+"Microsoft.Storage%2F"+"storageAccounts%2F"+stg_name+"/path/publish"

        usql_script = ""
        with open('order_data.sql','r') as usql:
            script = str(usql.read()).replace('\n','')
            usql_script =script.replace('storage_account_name',env['storage_name'])

        with open('run_analytics_job.html', 'r') as f:
            html_in_string_format = f.read()
            portal_adal_url= '\'https://portal.azure.com/#@'+tenant+'/resource/subscriptions/'+sub_id+'/resourceGroups/'+rg_name+'/providers/Microsoft.DataLakeAnalytics/accounts/'+adla_account_name+'/overview\''
            new_str = html_in_string_format.replace('portal_adal_url', portal_adal_url)
            html_str = new_str.replace('query_place_holder',usql_script)
            res_1 = html_str.replace('next_function_route', function_app_url)
            res_3 = res_1.replace('storagelinkholder',publish_url)
            returnData = {
                # HTTP Status Code:
                "status": 200,

                # Response Body:
                "body": res_3,

                # Send any number of HTTP headers
                "headers": {
                    "Content-Type": "text/html",
                    "X-Awesome-Header": "YesItIs"
                }
            }
            response.write(json.dumps(returnData))

    elif postreqdata['name'] == 'js_sender':   
        sub_id = env['subscription_id']
        rg_name = env['resource_group']
        tenant = env['tenant'] 
        storage_name=env['storage_name']
        eventhub_name=env['eventhub_name']
        eventhub_namespace=env['eventhub_namespace']
        sas_key=env['sas_key']
        DataAggregatorStreamAnalyticsJob1 = env['DataAggregatorStreamAnalyticsJob1']
        DataAggregatorStreamAnalyticsJob2 = env['DataAggregatorStreamAnalyticsJob2']
        DataAggregatorStreamAnalyticsJob3 = env['DataAggregatorStreamAnalyticsJob3']
        #a = requests.get('https://'+storage_name+'.blob.core.windows.net/web-ui/angular/views/eventhubdemoV3.html', allow_redirects=True)
        #a = requests.get('https://quickstartstorageaccount.blob.core.windows.net/web-ui/angular/views/eventhubdemoV3.html', allow_redirects=True)
        
        runid_second = second_df_starter()
        
        # a = requests.get('https://yashinnovationstorage.blob.core.windows.net/yash-datalake-resource/web-ui/angular/views/eventhubV_3.html', allow_redirects=True)
        with open('eventhubV3.html', 'r') as f:
            s = f.read()
            powerbi_online_portal_url = '\'https://powerbi.microsoft.com\''
            portal_stream_analytics_url_1= '\'https://portal.azure.com/#@'+tenant+'/resource/subscriptions/'+sub_id+'/resourceGroups/'+rg_name+'/providers/Microsoft.StreamAnalytics/streamingjobs/'+DataAggregatorStreamAnalyticsJob1+'/outputs\''
            portal_stream_analytics_url_2= '\'https://portal.azure.com/#@'+tenant+'/resource/subscriptions/'+sub_id+'/resourceGroups/'+rg_name+'/providers/Microsoft.StreamAnalytics/streamingjobs/'+DataAggregatorStreamAnalyticsJob2+'/outputs\''
            portal_stream_analytics_url_3= '\'https://portal.azure.com/#@'+tenant+'/resource/subscriptions/'+sub_id+'/resourceGroups/'+rg_name+'/providers/Microsoft.StreamAnalytics/streamingjobs/'+DataAggregatorStreamAnalyticsJob3+'/outputs\''        
            t = s.replace('portal_stream_analytics_url_1', portal_stream_analytics_url_1).replace('portal_stream_analytics_url_2', portal_stream_analytics_url_2).replace('portal_stream_analytics_url_3', portal_stream_analytics_url_3).replace('powerbi_online_portal_url',powerbi_online_portal_url)     
            b = t.replace('eventHubHolder','"'+eventhub_name+'"').replace('storage_account_name',storage_name)
            c = b.replace('SASKeyHolder','"'+sas_key+'"')
            d = c.replace('ehNamespaceName','"'+eventhub_namespace+'"')
            e = d.replace('next_function_route',function_app_url)
            f = e.replace('https://quickstartstorageaccount.blob.core.windows.net',"https://yashinnovationstorage.blob.core.windows.net/yash-datalake-resource")
            returnData = {
                # HTTP Status Code:
                "status": 200,

                # Response Body:
                # "body":"process done",
                "body":f,

                # Send any number of HTTP headers
                "headers": {
                "Content-Type": "text/html",
                "X-Awesome-Header": "YesItIs"
            }
            }
            # print 'first'
            response.write(json.dumps(returnData))

    elif postreqdata['name'] == 'adhoc':
        sub_id = env['subscription_id']
        rg_name = env['resource_group']
        tenant = env['tenant']
        adla_account_name = env['adla_account_name']
        adhoc_1_usql_script = ""
        adhoc_2_usql_script = ""
        adhoc_3_usql_script = ""  
        with open('adhoc_1.sql','r') as usql:
            script = str(usql.read()).replace('\n','')
            adhoc_1_usql_script = script.replace('storage_account_name',env['storage_name'])
        with open('adhoc_2.sql','r') as usql:
            script = str(usql.read()).replace('\n','')
            adhoc_2_usql_script = script.replace('storage_account_name',env['storage_name'])
        with open('adhoc_3.sql','r') as usql:
            script = str(usql.read()).replace('\n','')
            adhoc_3_usql_script = script.replace('storage_account_name',env['storage_name'])  
        with open('adhoc_analytics.html', 'r') as f:
            html_in_string_format = f.read()
            portal_adal_url= '\'https://portal.azure.com/#@'+tenant+'/resource/subscriptions/'+sub_id+'/resourceGroups/'+rg_name+'/providers/Microsoft.DataLakeAnalytics/accounts/'+adla_account_name+'/overview\''
            new_str = html_in_string_format.replace('portal_adal_url', portal_adal_url)
            html_str = new_str.replace('adhoc_1_query_place_holder',adhoc_1_usql_script).replace('adhoc_2_query_place_holder',adhoc_2_usql_script).replace('adhoc_3_query_place_holder',adhoc_3_usql_script)        
            returnData = {
                # HTTP Status Code:
                "status": 200,

                # Response Body:
                # "body":"process done",
                "body": html_str.replace('next_function_route', function_app_url),

                # Send any number of HTTP headers
                "headers": {
                "Content-Type": "text/html",
                "X-Awesome-Header": "YesItIs"
            }
            }
            response.write(json.dumps(returnData))
    
    elif postreqdata['name'] == 'powerbi':        
        with open('power_bi_details.html', 'r') as f:
            html_in_string_format = f.read()                        
            returnData = {
                # HTTP Status Code:
                "status": 200,

                # Response Body:quickstartstorageaccount
                # "body":"process done",
                "body": html_in_string_format.replace('next_function_route', function_app_url),

                # Send any number of HTTP headers
                "headers": {
                "Content-Type": "text/html",
                "X-Awesome-Header": "YesItIs"
            }
            }
            response.write(json.dumps(returnData))

    elif postreqdata['name'] == 'learn_more':        
        with open('learnmorepage.html', 'r') as f:
            html_in_string_format = f.read()                        
            returnData = {
                # HTTP Status Code:
                "status": 200,

                # Response Body:
                # "body":"process done",
                "body": html_in_string_format.replace('next_function_route', function_app_url),

                # Send any number of HTTP headers
                "headers": {
                "Content-Type": "text/html",
                "X-Awesome-Header": "YesItIs"
            }
            }
            response.write(json.dumps(returnData))

    elif postreqdata['name'] == 'run_stream_analytics_job':
        sub_id = env['subscription_id']
        app_id = env['web_app_id']
        app_secret = env['web_app_secret']
        tenant = env['tenant']
        rg_name = env['resource_group']
        stream_job1 = env['DataCleaningStreamAnalyticsJob']
        stream_job2 = env['DataAggregatorStreamAnalyticsJob1']
        stream_job3 = env['DataAggregatorStreamAnalyticsJob2']
        stream_job4 = env['DataAggregatorStreamAnalyticsJob3']

        run_stream_job("start",stream_job1,sub_id,rg_name,app_id,app_secret,tenant)
        time.sleep(5)
        run_stream_job("start",stream_job2,sub_id,rg_name,app_id,app_secret,tenant)
        time.sleep(5)
        run_stream_job("start",stream_job3,sub_id,rg_name,app_id,app_secret,tenant)
        time.sleep(5)
        run_stream_job("start",stream_job4,sub_id,rg_name,app_id,app_secret,tenant)
        response.write("Job started")

    elif postreqdata['name'] == 'stop_stream_analytics_job':
        sub_id = env['subscription_id']
        app_id = env['web_app_id']
        app_secret = env['web_app_secret']
        tenant = env['tenant']
        rg_name = env['resource_group']
        stream_job1 = env['DataCleaningStreamAnalyticsJob']
        stream_job2 = env['DataAggregatorStreamAnalyticsJob1']
        stream_job3 = env['DataAggregatorStreamAnalyticsJob2']
        stream_job4 = env['DataAggregatorStreamAnalyticsJob3']

        run_stream_job("stop",stream_job1,sub_id,rg_name,app_id,app_secret,tenant)
        time.sleep(5)
        run_stream_job("stop",stream_job2,sub_id,rg_name,app_id,app_secret,tenant)
        time.sleep(5)
        run_stream_job("stop",stream_job3,sub_id,rg_name,app_id,app_secret,tenant)
        time.sleep(5)
        run_stream_job("stop",stream_job4,sub_id,rg_name,app_id,app_secret,tenant)
        response.write("Job stopped")

    elif postreqdata['name'] == 'publish_dataset':
        app_id = env['web_app_id']
        app_secret = env['web_app_secret']
        tenant = env['tenant']
        token_1 = postreqdata['token']
        headers ={'Authorization': 'Bearer ' + token_1, 'Content-Type': 'application/json'}
        usql_script=""

        with open('order_data.sql','r') as usql:
            script = str(usql.read()).replace('\n','')
            usql_script =script.replace('storage_account_name',env['storage_name'])  
        
        guid=uuid.uuid4()
        data = {
            "jobId": str(guid),
            "name": "yashadlajob",
            "type": "USql",
            "degreeOfParallelism": 1,
            "priority": 1000,
            "properties": {
                "type": "USql",
                "script": usql_script
            }
        }

        url = "https://quickstartadla.azuredatalakeanalytics.net/jobs/"+str(guid)+"?api-version=2016-11-01"
        
        res = requests.put(url,data=json.dumps(data), headers=headers)
        response.write(str(guid))

    elif postreqdata['name'] == 'get_dataset':
        sub_id = env['subscription_id']
        rg_name = env['resource_group']
        df_name = env['datafactory_name']
        app_id = env['web_app_id']
        app_secret = env['web_app_secret']
        tenant = env['tenant']
        
        df_url = "https://management.azure.com/subscriptions/" + sub_id + "/resourceGroups/" + rg_name + "/providers/Microsoft.DataFactory/factories/" + df_name + "/pipelines/pipelineForDataMovement/createRun?api-version=2017-09-01-preview"
        run_id_json = df_run_id(df_url,app_id,app_secret,tenant)
        jsonresponse = run_id_json.json()
        run_id = jsonresponse['runId']
        response.write(run_id)

    elif postreqdata['name'] == 'create_transformed_datasets':
        sub_id = env['subscription_id']
        rg_name = env['resource_group']
        df_name = env['datafactory_name']
        app_id = env['web_app_id']
        app_secret = env['web_app_secret']
        tenant = env['tenant']
        stg_name = env['storage_name']
        transform_url = "https://portal.azure.com/" + "#blade/Microsoft_Azure_Storage/ContainerMenuBlade/overview/storageAccountId/" + "%2Fsubscriptions%2F" +sub_id+ "%2FresourceGroups%2F"+rg_name+"%2Fproviders%2F"+"Microsoft.Storage%2F"+"storageAccounts%2F"+stg_name+"/path/transformed"                        
        with open('create_transform_datasets.html', 'r') as f:
            html_in_string_format = str(f.read())

            res_1 = html_in_string_format.replace('next_function_route', function_app_url)
            res_3 = res_1.replace('storagelinkholder',transform_url)
            returnData = {
                # HTTP Status Code:
                "status": 200,

                # Response Body:
                "body": res_3,

                # Send any number of HTTP headers
                "headers": {
                    "Content-Type": "text/html",
                    "X-Awesome-Header": "YesItIs"
                }
            }
            response.write(json.dumps(returnData))

    elif postreqdata['name'] == 'df_status':
        sub_id = env['subscription_id']
        run_id = postreqdata['run_id']
        print run_id
        rg_name = env['resource_group']
        df_name = env['datafactory_name']
        app_id = env['web_app_id']
        app_secret = env['web_app_secret']
        tenant = env['tenant']
        req_url = "https://management.azure.com/subscriptions/" + sub_id + "/resourceGroups/" + rg_name + "/providers/Microsoft.DataFactory/factories/" + df_name + "/pipelineruns/" + str(run_id) + "?api-version=2017-09-01-preview"
        df_st = df_status(req_url,app_id,app_secret,tenant)
        response.write(df_st)
    
    elif postreqdata['name'] == 'adla_status':
        job_id = postreqdata['run_id']
        adla_account_name = env['adla_account_name']

        app_id = env['web_app_id']
        app_secret = env['web_app_secret']
        tenant = env['tenant']

        jobResult = adla_run_job_status(job_id,adla_account_name,app_id,app_secret,tenant)
        
        response.write(str(jobResult.state))

    elif postreqdata['name'] == 'neo4j':
        with open('Neo4JCallback.html', 'r') as f:
                html_in_string_format = str(f.read())
                html_in_string = html_in_string_format.replace('localhosts', vm_ip)
                html = html_in_string.replace('next_function_route',function_app_url)
                # res = html.replace('showNodeListplaceholder','showNodeList')
                returnData = {
                    # HTTP Status Code:
                    "status": 200,

                    # Response Body:
                    "body": html,
                    
                    # Send any number of HTTP headers
                    "headers": {
                        "Content-Type": "text/html",
                        "X-Awesome-Header": "YesItIs"
                    }
                }
                response.write(json.dumps(returnData))
    
    elif postreqdata['name'] == 'get_node_list':
        nodeName = postreqdata['nodename']
        # response.write("showNodeList")
        with open('showNodeList.html', 'r') as f:
                html_in_string_format = str(f.read())
                html_in_string = html_in_string_format.replace('localhosts', vm_ip)
                html = html_in_string.replace('next_function_route',function_app_url)
                res_html = html.replace('NName',nodeName)
                returnData = {
                    # HTTP Status Code:
                    "status": 200,

                    # Response Body:
                    "body": res_html,
                    
                    # Send any number of HTTP headers
                    "headers": {
                        "Content-Type": "text/html",
                        "X-Awesome-Header": "YesItIs"
                    }
                }
                response.write(json.dumps(returnData))
    


    elif postreqdata['name'] == 'neo4jshowgraph':
        nodeName = postreqdata['nodename']
        with open('showD3Graph.html', 'r') as f:
                html_in_string_format = str(f.read())
                html_in_string = html_in_string_format.replace('localhosts', vm_ip)
                html = html_in_string.replace('next_function_route',function_app_url)
                res_html = html.replace('NName',str(nodeName))

                returnData = {
                    # HTTP Status Code:
                    "status": 200,

                    # Response Body:
                    "body": res_html,

                    # Send any number of HTTP headers
                    "headers": {
                        "Content-Type": "text/html",
                        "X-Awesome-Header": "YesItIs"
                    }
                }
                response.write(json.dumps(returnData))

    elif postreqdata['name'] == 'elk_stack':
        
        with open('elkstack.html', 'r') as f:
                html_in_string_format = str(f.read())
                html_in_string = html_in_string_format.replace('localhosts', vm_ip)
                res_html = html_in_string.replace('next_function_route',function_app_url)
                # res_html = html.replace('NName',str(nodeName))

                returnData = {
                    # HTTP Status Code:
                    "status": 200,

                    # Response Body:
                    "body": res_html,

                    # Send any number of HTTP headers
                    "headers": {
                        "Content-Type": "text/html",
                        "X-Awesome-Header": "YesItIs"
                    }
                }
                response.write(json.dumps(returnData))
    elif postreqdata['name'] == 'neo4j2':
        
        with open('neo4j.html', 'r') as f:
                html_in_string_format = str(f.read())
                html_in_string = html_in_string_format.replace('localhosts', vm_ip)
                res_html = html_in_string.replace('next_function_route',function_app_url)
                # res_html = html.replace('NName',str(nodeName))

                returnData = {
                    # HTTP Status Code:
                    "status": 200,

                    # Response Body:
                    "body": res_html,

                    # Send any number of HTTP headers
                    "headers": {
                        "Content-Type": "text/html",
                        "X-Awesome-Header": "YesItIs"
                    }
                }
                response.write(json.dumps(returnData))

    else:
        response.write('invalid request')

response.close()

